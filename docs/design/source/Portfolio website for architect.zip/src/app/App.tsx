import { useEffect, useRef, useState } from "react"
import {
  createBrowserRouter,
  Link,
  RouterProvider,
  useLocation,
  useParams,
} from "react-router"

const image = (id: string, width = 1800) =>
  `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=${width}&q=85`
const projects = [
  {
    slug: "casa-bruma",
    name: "Casa Bruma",
    type: "Residential architecture",
    filter: "ARCHITECTURE",
    location: "Lima, Perú",
    year: "2026",
    image: "1546414701-81cc6963c67f",
    area: "420 m²",
    status: "Completed",
  },
  {
    slug: "monolito",
    name: "Monolito",
    type: "Cultural architecture",
    filter: "ARCHITECTURE",
    location: "Ciudad de México",
    year: "2025",
    image: "1522743791393-522312deeebf",
    area: "1,860 m²",
    status: "In development",
  },
  {
    slug: "patio-interior",
    name: "Patio Interior",
    type: "Interior design",
    filter: "INTERIORS",
    location: "Madrid, España",
    year: "2025",
    image: "1600210492486-724fe5c67fb0",
    area: "240 m²",
    status: "Completed",
  },
  {
    slug: "entre-planos",
    name: "Entre Planos",
    type: "Spatial exploration",
    filter: "CONCEPT",
    location: "Lima, Perú",
    year: "2024",
    image: "1536924491042-b0466800ce46",
    area: "680 m²",
    status: "Concept",
  },
  {
    slug: "materia",
    name: "Materia",
    type: "Architectural visualization",
    filter: "3D",
    location: "Barcelona, España",
    year: "2024",
    image: "1565626424178-c699f6601afd",
    area: "320 m²",
    status: "Concept",
  },
  {
    slug: "luz-y-silencio",
    name: "Luz y Silencio",
    type: "Atmospheric render",
    filter: "RENDERS",
    location: "Lisboa, Portugal",
    year: "2023",
    image: "1595658511703-2cad160de181",
    area: "520 m²",
    status: "Concept",
  },
  {
    slug: "volumen-04",
    name: "Volumen 04",
    type: "Study model",
    filter: "MODELS",
    location: "Lima, Perú",
    year: "2023",
    image: "1557838258-c5854ee2eee7",
    area: "1:100",
    status: "Research",
  },
]
type Project = typeof projects[number]
const label = "font-mono text-[10px] uppercase tracking-[0.09em]"
const margin = "px-6 md:px-12 lg:px-16"

function Reveal({
  children,
  className = "",
}: {
  children: React.ReactNode
  className?: string
}) {
  const ref = useRef<HTMLDivElement>(null)
  const [visible, setVisible] = useState(false)
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true)
          observer.disconnect()
        }
      },
      { threshold: 0.08 },
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])
  return (
    <div
      ref={ref}
      className={`${className} transition-all duration-1000 motion-reduce:translate-y-0 motion-reduce:opacity-100 ${
        visible ? "translate-y-0 opacity-100" : "translate-y-8 opacity-0"
      }`}
    >
      {children}
    </div>
  )
}

function Header() {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const location = useLocation()
  useEffect(() => {
    const update = () => setScrolled(window.scrollY > 50)
    update()
    window.addEventListener("scroll", update, { passive: true })
    return () => window.removeEventListener("scroll", update)
  }, [])
  useEffect(() => {
    setOpen(false)
    window.scrollTo(0, 0)
  }, [location.pathname])
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : ""
    const escape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false)
    }
    window.addEventListener("keydown", escape)
    return () => {
      document.body.style.overflow = ""
      window.removeEventListener("keydown", escape)
    }
  }, [open])
  const items = ["Projects", "Studio", "Services", "About", "Contact"]
  return (
    <>
      <header
        className={`fixed top-0 z-50 flex w-full items-center justify-between ${margin} py-6 transition-all duration-500 ${
          scrolled || open
            ? "bg-background/95 text-foreground backdrop-blur-md"
            : "text-white"
        }`}
      >
        <Link
          to="/"
          aria-label="Mateo Varela home"
          className="flex items-center gap-3"
        >
          <span className="font-display text-xl font-extrabold leading-[0.86] tracking-[-0.8px]">
            MATEO
            <br />
            VARELA<span className="text-primary">.</span>
          </span>
          <span className="ml-2 hidden h-7 border-l border-current pl-4 font-mono text-[8px] leading-3 tracking-wider sm:block">
            ARCHITECTURE
            <br />& DESIGN
          </span>
        </Link>
        <nav className="hidden items-center gap-8 lg:flex">
          {items.map((item) => (
            <a
              key={item}
              href={`/#${item.toLowerCase()}`}
              className={`text-[11px] transition-opacity hover:opacity-50 ${
                item === "Contact" ? "ml-4" : ""
              }`}
            >
              {item}
              {item === "Contact" && <span className="ml-3">↗</span>}
            </a>
          ))}
        </nav>
        <button
          onClick={() => setOpen(!open)}
          aria-expanded={open}
          aria-label={open ? "Close menu" : "Open menu"}
          className="flex items-center gap-3 lg:hidden"
        >
          <span className={label}>{open ? "Close" : "Menu"}</span>
          <span className="text-2xl">{open ? "×" : "+"}</span>
        </button>
      </header>
      {open && (
        <nav className="fixed inset-0 z-40 flex flex-col justify-center gap-5 bg-background px-6">
          {items.map((item, index) => (
            <a
              key={item}
              onClick={() => setOpen(false)}
              href={`/#${item.toLowerCase()}`}
              className="font-display text-5xl"
            >
              <sup className="mr-5 font-mono text-xs text-primary">
                0{index + 1}
              </sup>
              {item}
            </a>
          ))}
          <p className={`${label} mt-12`}>Lima, Perú · Working everywhere</p>
        </nav>
      )}
    </>
  )
}

function ProjectHero({ project }: { project?: Project }) {
  const [offset, setOffset] = useState(0)
  useEffect(() => {
    const update = () => {
      if (window.scrollY < window.innerHeight) setOffset(window.scrollY)
    }
    window.addEventListener("scroll", update, { passive: true })
    return () => window.removeEventListener("scroll", update)
  }, [])
  return (
    <section className="relative h-[92svh] min-h-[650px] overflow-hidden bg-stone-500 text-white md:min-h-[730px]">
      <img
        src={image(project?.image || projects[0].image, 2400)}
        alt={
          project
            ? `${project.name}, contemporary architectural study`
            : "Monumental concrete architecture with sculptural horizontal forms"
        }
        fetchPriority="high"
        className="absolute h-full w-full object-cover brightness-[0.68] motion-reduce:!transform-none"
        style={{
          transform: `scale(${1 + offset * 0.00009}) translateY(${offset * 0.12}px)`,
        }}
      />
      <div
        className={`relative flex h-full flex-col justify-end ${margin} pb-10 pt-36`}
      >
        <div className="absolute right-6 top-[140px] hidden items-center gap-3 md:right-12 md:flex">
          <span className="h-1.5 w-1.5 rounded-full bg-white" />
          <span className={label}>Independent architecture studio</span>
        </div>
        <div className={`${label} mb-7 flex items-center gap-3`}>
          <span className="h-1.5 w-1.5 bg-primary" />
          {project
            ? `${project.type} / ${project.year}`
            : "Space. Matter. Human experience."}
        </div>
        <h1 className="font-display text-[clamp(54px,7.75vw,126px)] font-medium uppercase leading-[0.99] tracking-[-0.045em]">
          {project ? (
            project.name
          ) : (
            <>
              ARCHITECTURE
              <br />
              THAT SHAPES
              <br />
              <span className="flex items-center gap-4 md:gap-8">
                EXPERIENCE
                <span className="inline-block text-[0.7em] font-normal">↗</span>
              </span>
            </>
          )}
        </h1>
        <div className="mt-12 grid grid-cols-2 items-end border-t border-white/35 pt-5 md:mt-14 md:grid-cols-3">
          <span className={label}>
            {project ? project.location : "Selected works · 2023—2026"}
          </span>
          <span className={`${label} hidden text-center md:block`}>
            12°02′35″S &nbsp; 77°01′41″W
          </span>
          <a
            href={project ? "#narrative" : "#projects"}
            className={`${label} text-right`}
          >
            Scroll to explore <span className="ml-4 text-lg">↓</span>
          </a>
        </div>
      </div>
      <div className="absolute bottom-40 right-12 hidden flex-col items-center gap-4 lg:flex">
        <span className={`${label} [writing-mode:vertical-rl]`}>
          01 / 07 — CASA BRUMA
        </span>
        <span className="h-16 w-px bg-white/70" />
      </div>
    </section>
  )
}

function ProjectCard({
  project,
  number,
  className = "",
  portrait = false,
}: {
  project: Project
  number: number
  className?: string
  portrait?: boolean
}) {
  return (
    <Reveal className={className}>
      <Link to={`/projects/${project.slug}`} className="group block">
        <div
          className={`relative overflow-hidden bg-muted ${
            portrait ? "aspect-[4/5]" : "aspect-[16/10]"
          }`}
        >
          <img
            src={image(project.image)}
            alt={`${project.name} — ${project.type}`}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-[1500ms] group-hover:scale-105"
          />
          <span
            className={`${label} absolute bottom-6 right-6 bg-background px-5 py-3 opacity-0 transition-all group-hover:opacity-100`}
          >
            View project ↗
          </span>
        </div>
        <div className="mt-5 flex justify-between gap-3">
          <div className="flex items-start gap-4">
            <span className={`${label} pt-1 text-primary`}>0{number}</span>
            <div>
              <h3 className="font-display text-xl uppercase transition-transform group-hover:translate-x-2 md:text-2xl">
                {project.name}
              </h3>
              <p className="mt-1 text-xs text-muted-foreground">
                {project.type}
              </p>
            </div>
          </div>
          <div className={`${label} pt-1 text-right text-muted-foreground`}>
            {project.location}
            <br />
            <span className="mt-2 inline-block">{project.year}</span>
          </div>
        </div>
      </Link>
    </Reveal>
  )
}

function ProjectFilter({
  selected,
  onSelect,
}: {
  selected: string
  onSelect: (value: string) => void
}) {
  return (
    <div className="flex flex-wrap gap-x-6 gap-y-4">
      {[
        "ALL",
        "ARCHITECTURE",
        "INTERIORS",
        "3D",
        "RENDERS",
        "MODELS",
        "CONCEPT",
      ].map((filter) => (
        <button
          key={filter}
          aria-pressed={selected === filter}
          onClick={() => onSelect(filter)}
          className={`${label} border-b pb-2 transition-colors ${
            selected === filter
              ? "border-primary text-primary"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          {filter}
          {filter === "ALL" ? " (07)" : ""}
        </button>
      ))}
    </div>
  )
}

function ProjectIndex() {
  const [filter, setFilter] = useState("ALL")
  const [preview, setPreview] = useState<Project | null>(null)
  const [position, setPosition] = useState({ x: 0, y: 0 })
  return (
    <section className={`${margin} py-24 md:py-36`}>
      <div className="mb-12 flex items-end justify-between">
        <h2 className="font-display text-4xl md:text-6xl">
          PROJECT INDEX<span className="text-primary">.</span>
        </h2>
        <span className={`${label} hidden md:block`}>
          A continuing body of work / 2023—2026
        </span>
      </div>
      <ProjectFilter selected={filter} onSelect={setFilter} />
      <div
        className={`${label} mt-10 grid grid-cols-[1fr_70px] border-b border-border py-4 text-muted-foreground md:grid-cols-[2fr_1fr_1fr_70px]`}
      >
        <span>Project</span>
        <span className="hidden md:block">Type</span>
        <span className="hidden md:block">Location</span>
        <span className="text-right">Year</span>
      </div>
      {projects
        .filter((project) => filter === "ALL" || project.filter === filter)
        .map((project) => (
          <Link
            to={`/projects/${project.slug}`}
            key={project.slug}
            onMouseEnter={() => setPreview(project)}
            onMouseLeave={() => setPreview(null)}
            onMouseMove={(event) =>
              setPosition({ x: event.clientX, y: event.clientY })
            }
            className="group grid grid-cols-[1fr_70px] items-center border-b border-border py-6 transition-colors hover:text-primary md:grid-cols-[2fr_1fr_1fr_70px]"
          >
            <span className="font-display text-xl md:text-2xl">
              <span className={`${label} mr-5 text-muted-foreground`}>
                0{projects.indexOf(project) + 1}
              </span>
              {project.name}
            </span>
            <span className="hidden text-xs md:block">{project.type}</span>
            <span className="hidden text-xs md:block">{project.location}</span>
            <span className={`${label} text-right`}>{project.year} ↗</span>
          </Link>
        ))}
      {preview && (
        <img
          src={image(preview.image, 700)}
          alt=""
          className="pointer-events-none fixed z-30 hidden h-56 w-80 object-cover shadow-xl lg:block"
          style={{
            left: Math.min(position.x + 30, window.innerWidth - 340),
            top: Math.max(100, position.y - 240),
          }}
        />
      )}
    </section>
  )
}

function ProjectMetadata({ project }: { project: Project }) {
  return (
    <div className="grid grid-cols-2 gap-x-6 gap-y-8 md:grid-cols-3 lg:grid-cols-6">
      {[
        ["Location", project.location],
        ["Year", project.year],
        ["Area", project.area],
        ["Status", project.status],
        ["Program", project.type],
        ["Role", "Design & direction"],
      ].map(([key, value]) => (
        <div key={key} className="border-t border-current/25 pt-4">
          <p className={`${label} opacity-60`}>{key}</p>
          <p className="mt-3 text-sm">{value}</p>
        </div>
      ))}
    </div>
  )
}

function FeaturedProject() {
  const project = projects[1]
  return (
    <section className="relative min-h-[800px] overflow-hidden bg-stone-800 text-white">
      <img
        src={image(project.image, 2200)}
        alt="Monolito, sculptural concrete cultural building"
        loading="lazy"
        className="absolute h-full w-full object-cover brightness-50"
      />
      <div
        className={`relative flex min-h-[800px] flex-col justify-between ${margin} py-12 md:py-16`}
      >
        <div className="flex justify-between">
          <span className={label}>Featured project / 02</span>
          <span className={label}>An exercise in permanence</span>
        </div>
        <Reveal>
          <h2 className="font-display text-[clamp(60px,12vw,180px)] uppercase leading-none tracking-[-0.045em]">
            MONOLITO
          </h2>
          <div className="mt-8 flex flex-col justify-between gap-8 md:flex-row">
            <p className="max-w-sm text-sm leading-relaxed text-white/80">
              A dialogue between mass and void. An open cultural landscape where
              concrete, light and human encounters become one.
            </p>
            <Link
              className={`${label} self-start border-b border-white/60 pb-3`}
              to={`/projects/${project.slug}`}
            >
              Explore project <span className="ml-10">↗</span>
            </Link>
          </div>
        </Reveal>
        <ProjectMetadata project={project} />
      </div>
    </section>
  )
}

function ProfileSection() {
  return (
    <section id="studio" className={`${margin} py-24 md:py-36`}>
      <div className="mb-14 flex justify-between border-t border-border pt-5">
        <span className={label}>03 / The studio</span>
        <span className={`${label} text-muted-foreground`}>
          Independent thinking. Shared possibilities.
        </span>
      </div>
      <div id="about" className="grid gap-14 lg:grid-cols-[1.2fr_0.8fr]">
        <Reveal>
          <h2 className="font-display text-[clamp(35px,4.3vw,68px)] font-medium leading-[1.1] tracking-[-0.035em]">
            DESIGNING SPACES
            <br />
            THAT CREATE
            <br />
            MEMORABLE
            <br />
            EXPERIENCES<span className="text-primary">.</span>
          </h2>
          <p className="mt-8 max-w-md text-sm leading-7 text-muted-foreground">
            I’m Mateo Varela, an architect based in Lima, working at the
            intersection of architecture, landscape and human experience. My
            practice explores how thoughtful spaces can transform the way we
            live, connect and feel.
          </p>
          <a
            href="mailto:hello@mateovarela.studio"
            className={`${label} mt-8 inline-block border-b border-foreground pb-3`}
          >
            More about the practice ↗
          </a>
          <div className="mt-14 flex gap-8 border-t border-border pt-7 md:gap-14">
            {[
              ["24+", "Projects"],
              ["6", "Years experience"],
              ["4", "Cities"],
            ].map(([number, text]) => (
              <div key={text}>
                <p className="font-display text-4xl md:text-5xl">{number}</p>
                <p className={`${label} mt-3 text-muted-foreground`}>{text}</p>
              </div>
            ))}
          </div>
        </Reveal>
        <Reveal className="lg:pt-12">
          <img
            src={image("1497366811353-6870744d04b2", 1000)}
            alt="Light-filled architecture studio with work tables and materials"
            loading="lazy"
            className="aspect-[4/5] w-full bg-muted object-cover"
          />
          <div
            className={`${label} mt-4 flex justify-between text-muted-foreground`}
          >
            <span>A space for ideas to take shape.</span>
            <span>Lima, PE / 2026</span>
          </div>
        </Reveal>
      </div>
    </section>
  )
}

function ServiceList() {
  const [active, setActive] = useState(0)
  return (
    <section
      id="services"
      className={`${margin} grid gap-12 bg-secondary py-20 lg:grid-cols-[0.9fr_1.1fr] lg:gap-24`}
    >
      <div>
        <span className={label}>04 / Capabilities</span>
        <h2 className="mt-6 font-display text-4xl leading-tight md:text-5xl">
          FROM THE FIRST IDEA.
          <br />
          TO THE LAST DETAIL.
        </h2>
        <img
          src={image(projects[active].image, 800)}
          alt={`${["Architecture", "Interior design", "3D visualization", "Architectural models", "Concept design"][active]} preview`}
          loading="lazy"
          className="mt-10 aspect-[16/10] w-full object-cover transition-opacity"
        />
      </div>
      <div className="self-center">
        {[
          "Architecture",
          "Interior Design",
          "3D Visualization",
          "Architectural Models",
          "Concept Design",
        ].map((service, index) => (
          <button
            key={service}
            onMouseEnter={() => setActive(index)}
            onFocus={() => setActive(index)}
            onClick={() => setActive(index)}
            className={`flex w-full items-center justify-between border-b border-border py-6 text-left transition-colors ${
              active === index ? "text-primary" : "text-foreground"
            }`}
          >
            <span className="flex items-center gap-6">
              <span className={label}>0{index + 1}</span>
              <span className="font-display text-2xl md:text-3xl">
                {service}
              </span>
            </span>
            <span className="text-2xl">↗</span>
          </button>
        ))}
      </div>
    </section>
  )
}

function MediaGallery() {
  const [selected, setSelected] = useState<number | null>(null)
  useEffect(() => {
    if (selected === null) return
    const close = (event: KeyboardEvent) => {
      if (event.key === "Escape") setSelected(null)
    }
    document.body.style.overflow = "hidden"
    window.addEventListener("keydown", close)
    return () => {
      document.body.style.overflow = ""
      window.removeEventListener("keydown", close)
    }
  }, [selected])
  const media = [projects[3], projects[4], projects[6]]
  return (
    <section className={`${margin} py-24 md:py-36`}>
      <div className="mb-14 flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <h2 className="font-display text-4xl md:text-6xl">
          VISUAL
          <br />
          EXPLORATIONS<span className="text-primary">.</span>
        </h2>
        <p className="max-w-xs text-xs leading-6 text-muted-foreground">
          Ideas in progress. Studies in light, form and material.
          <br />A playground for the unbuilt.
        </p>
      </div>
      <div className="grid grid-cols-2 items-start gap-5 md:grid-cols-[1.2fr_0.8fr_1fr] md:gap-9">
        {media.map((project, index) => (
          <Reveal
            key={project.slug}
            className={
              index === 1
                ? "pt-20 md:pt-36"
                : index === 2
                  ? "col-span-2 md:col-span-1 md:pt-12"
                  : ""
            }
          >
            <button
              onClick={() => setSelected(index)}
              className="group w-full text-left"
            >
              <div className="overflow-hidden bg-muted">
                <img
                  src={image(project.image, 900)}
                  alt={project.name}
                  loading="lazy"
                  className={`${
                    index === 1 ? "aspect-square" : "aspect-[3/4]"
                  } w-full object-cover transition-transform duration-1000 group-hover:scale-105`}
                />
              </div>
              <div className={`${label} mt-4 flex justify-between`}>
                <span>Study / 0{index + 1}</span>
                <span>{project.filter} ↗</span>
              </div>
            </button>
          </Reveal>
        ))}
      </div>
      {selected !== null && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={media[selected].name}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 p-6"
          onClick={() => setSelected(null)}
        >
          <button
            autoFocus
            aria-label="Close image"
            className="absolute right-6 top-6 text-3xl text-white"
            onClick={() => setSelected(null)}
          >
            ×
          </button>
          <img
            src={image(media[selected].image, 2000)}
            alt={media[selected].name}
            className="max-h-[85vh] max-w-full object-contain"
          />
        </div>
      )}
    </section>
  )
}

function ContactSection() {
  return (
    <section
      id="contact"
      className={`${margin} bg-[#22241f] py-20 text-[#f4f4ec] md:py-28`}
    >
      <div className="flex justify-between">
        <span className={label}>06 / New possibilities</span>
        <span className={`${label} flex items-center gap-2`}>
          <span className="h-1.5 w-1.5 rounded-full bg-primary" />
          Available for selected collaborations
        </span>
      </div>
      <h2 className="my-14 font-display text-[clamp(46px,8.7vw,140px)] font-medium leading-[1.02] tracking-[-0.04em]">
        LET’S CREATE
        <br />
        SOMETHING
        <br />
        <a
          href="mailto:hello@mateovarela.studio"
          className="transition-colors hover:text-primary"
        >
          REMARKABLE ↗
        </a>
      </h2>
      <div className="grid gap-8 border-t border-white/25 pt-8 md:grid-cols-3">
        <a
          href="mailto:hello@mateovarela.studio"
          className="font-display text-xl"
        >
          Start a project →
          <span className="mt-4 block font-sans text-xs text-white/60">
            hello@mateovarela.studio
          </span>
        </a>
        <div className="flex gap-7 text-xs">
          <a target="_blank" rel="noreferrer" href="https://www.instagram.com/">
            Instagram ↗
          </a>
          <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/">
            LinkedIn ↗
          </a>
        </div>
        <span className={`${label} md:text-right`}>
          Based in Lima, Perú
          <br />
          <span className="mt-3 inline-block text-white/60">
            Working everywhere.
          </span>
        </span>
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer
      className={`${margin} flex flex-wrap items-center justify-between gap-5 py-7`}
    >
      <Link to="/" className="font-display text-sm font-bold">
        MATEO VARELA<span className="text-primary">.</span>
      </Link>
      <span className={`${label} text-muted-foreground`}>
        © 2026 Mateo Varela · Architecture & design
      </span>
      <button
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        className={label}
      >
        Back to top ↑
      </button>
    </footer>
  )
}

function Home() {
  return (
    <>
      <Header />
      <main>
        <ProjectHero />
        <section
          id="projects"
          className={`${margin} pb-12 pt-14 md:pb-20 md:pt-20`}
        >
          <div className="mb-14 flex items-end justify-between border-b border-border pb-6">
            <div>
              <p className={`${label} mb-4 text-muted-foreground`}>
                01 / A selection of our work
              </p>
              <h2 className="font-display text-[clamp(30px,4vw,60px)] font-medium leading-none tracking-[-0.03em]">
                SELECTED PROJECTS
                <span className="align-top font-mono text-xs text-primary">
                  {" "}
                  (04)
                </span>
              </h2>
            </div>
            <a
              href="#project-index"
              className={`${label} hidden pb-1 sm:block`}
            >
              View project index ↗
            </a>
          </div>
          <div className="grid gap-x-12 gap-y-16 md:grid-cols-12">
            <ProjectCard
              project={projects[0]}
              number={1}
              className="md:col-span-8"
            />
            <div className="hidden self-end pb-20 md:col-span-4 md:block">
              <span className={`${label} text-primary`}>
                Architecture as a way of seeing.
              </span>
              <p className="mt-5 max-w-xs font-display text-xl leading-relaxed">
                Spaces that respond to their surroundings.
                <br />
                And stay with the people who inhabit them.
              </p>
              <div className="mt-10 text-5xl font-light">↙</div>
            </div>
            <ProjectCard
              project={projects[1]}
              number={2}
              portrait
              className="md:col-span-5 md:mt-4"
            />
            <ProjectCard
              project={projects[2]}
              number={3}
              className="md:col-span-6 md:col-start-7 md:mt-32"
            />
            <ProjectCard
              project={projects[3]}
              number={4}
              className="md:col-span-9 md:col-start-3 md:mt-8"
            />
          </div>
        </section>
        <div id="project-index">
          <ProjectIndex />
        </div>
        <FeaturedProject />
        <ProfileSection />
        <ServiceList />
        <MediaGallery />
        <ContactSection />
      </main>
      <Footer />
    </>
  )
}

function ProjectGallery({ project }: { project: Project }) {
  return (
    <div className="space-y-16 md:space-y-28">
      <Reveal>
        <img
          src={image(project.image, 2200)}
          alt={`${project.name} — exterior elevation`}
          className="aspect-[16/9] w-full bg-muted object-cover"
        />
      </Reveal>
      <div className={`${margin} grid items-center gap-12 md:grid-cols-2`}>
        <Reveal>
          <img
            src={image("1565626424178-c699f6601afd")}
            alt="Concrete geometry and structural detail"
            className="aspect-[4/5] w-full bg-muted object-cover"
          />
        </Reveal>
        <Reveal className="md:px-12">
          <span className={`${label} text-primary`}>02 / Material & light</span>
          <h2 className="mt-6 font-display text-4xl leading-tight md:text-5xl">
            The quiet power
            <br />
            of simple forms.
          </h2>
          <p className="mt-7 max-w-sm text-sm leading-7 text-muted-foreground">
            A restrained material palette lets the architecture reveal itself
            through changing light. Every threshold invites a new perspective,
            connecting the intimate with the monumental.
          </p>
        </Reveal>
      </div>
      <div className={`${margin} grid gap-6 md:grid-cols-2`}>
        <img
          src={image("1536924491042-b0466800ce46")}
          alt="Architectural composition of planes and shadows"
          loading="lazy"
          className="aspect-[4/5] w-full object-cover"
        />
        <img
          src={image("1595658511703-2cad160de181")}
          alt="Facade study and architectural rhythm"
          loading="lazy"
          className="aspect-[4/5] w-full object-cover md:mt-20"
        />
      </div>
    </div>
  )
}

function ProjectPage() {
  const { slug } = useParams()
  const project = projects.find((item) => item.slug === slug)
  if (!project)
    return (
      <>
        <Header />
        <main className="flex min-h-screen flex-col items-center justify-center gap-8">
          <h1 className="font-display text-4xl">Project not found.</h1>
          <Link to="/">Return to selected works ↗</Link>
        </main>
      </>
    )
  const next = projects[(projects.indexOf(project) + 1) % projects.length]
  return (
    <>
      <Header />
      <main>
        <ProjectHero project={project} />
        <section id="narrative" className={`${margin} py-20 md:py-28`}>
          <ProjectMetadata project={project} />
          <div className="my-20 grid gap-8 md:grid-cols-2">
            <span className={`${label} text-primary`}>01 / The idea</span>
            <div>
              <h2 className="font-display text-4xl leading-tight md:text-5xl">
                Between the built
                <br />
                and the experienced.
              </h2>
              <p className="mt-7 max-w-lg text-sm leading-7 text-muted-foreground">
                {project.name} explores a fundamental question: how can
                architecture create a deeper connection to place? Through
                considered proportions, honest materials and a sensitivity to
                natural light, the project creates a sequence of spaces that
                feels both unexpected and inevitable.
              </p>
            </div>
          </div>
        </section>
        <ProjectGallery project={project} />
        <Link
          to={`/projects/${next.slug}`}
          className="group relative mt-28 block h-[75vh] overflow-hidden bg-stone-700 text-white"
        >
          <img
            src={image(next.image, 2200)}
            alt={`Next project: ${next.name}`}
            className="absolute h-full w-full object-cover brightness-60 transition-transform duration-[1500ms] group-hover:scale-105"
          />
          <div
            className={`relative flex h-full flex-col justify-end ${margin} py-14`}
          >
            <span className={label}>Next project →</span>
            <h2 className="mt-6 font-display text-[clamp(48px,9vw,140px)] uppercase leading-none">
              {next.name} ↗
            </h2>
          </div>
        </Link>
        <ContactSection />
      </main>
      <Footer />
    </>
  )
}

const router = createBrowserRouter([
  { path: "/", Component: Home },
  { path: "/projects/:slug", Component: ProjectPage },
  { path: "*", Component: Home },
])
export default function App() {
  return <RouterProvider router={router} />
}
