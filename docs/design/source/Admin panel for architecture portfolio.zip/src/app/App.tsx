import { useEffect, useRef, useState, type ReactNode } from "react"
import {
  createBrowserRouter,
  RouterProvider,
  useLocation,
  useNavigate,
} from "react-router"
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Bell,
  Box,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  Copy,
  ExternalLink,
  File,
  FolderOpen,
  GripVertical,
  Image,
  LayoutDashboard,
  LayoutGrid,
  List,
  LogOut,
  Mail,
  Menu,
  MoreHorizontal,
  Plus,
  Search,
  Settings,
  SlidersHorizontal,
  Trash2,
  Upload,
  UserRound,
  X,
  BriefcaseBusiness,
  Eye,
  Save,
  Globe,
} from "lucide-react"

type Status = "Published" | "Draft" | "Archived"
type Project = {
  id: number
  name: string
  category: string
  location: string
  year: string
  status: Status
  image: string
  description?: string
  fields?: Record<string, string>
}
const photo = (id: string) =>
  `https://images.unsplash.com/${id}?auto=format&fit=crop&w=1000&q=85`
const initialProjects: Project[] = [
  {
    id: 1,
    name: "The Courtyard House",
    category: "Residential",
    location: "Barcelona, Spain",
    year: "2024",
    status: "Published",
    image: photo("photo-1630908932803-1f6891bfab3f"),
  },
  {
    id: 2,
    name: "Forma Cultural Center",
    category: "Cultural",
    location: "Lisbon, Portugal",
    year: "2024",
    status: "Published",
    image: photo("photo-1630492107795-abe50af2282f"),
  },
  {
    id: 3,
    name: "Still House",
    category: "Residential",
    location: "Mallorca, Spain",
    year: "2025",
    status: "Draft",
    image: photo("photo-1630664041972-547be0f3134f"),
  },
  {
    id: 4,
    name: "White Pavilion",
    category: "Commercial",
    location: "Porto, Portugal",
    year: "2023",
    status: "Published",
    image: photo("photo-1622396481322-3b83d186701b"),
  },
  {
    id: 5,
    name: "Urban Threshold",
    category: "Cultural",
    location: "Madrid, Spain",
    year: "2023",
    status: "Archived",
    image: photo("photo-1549791084-5f78368b208b"),
  },
  {
    id: 6,
    name: "House by the Garden",
    category: "Residential",
    location: "Girona, Spain",
    year: "2025",
    status: "Draft",
    image: photo("photo-1630664289242-3dd9b9863c24"),
  },
]
const navItems = [
  { name: "Dashboard", path: "", icon: LayoutDashboard },
  { name: "Projects", path: "projects", icon: FolderOpen },
  { name: "Media", path: "media", icon: Image },
  { name: "Profile", path: "profile", icon: UserRound },
  { name: "Services", path: "services", icon: BriefcaseBusiness },
  { name: "Messages", path: "messages", icon: Mail },
  { name: "Settings", path: "settings", icon: Settings },
]
const inputClass =
  "w-full rounded border border-border bg-white px-3 py-2.5 text-sm transition focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/10 placeholder:text-muted-foreground"
function Button({
  children,
  onClick,
  secondary = false,
  className = "",
  disabled = false,
  type = "button",
}: {
  children: ReactNode
  onClick?: () => void
  secondary?: boolean
  className?: string
  disabled?: boolean
  type?: "button" | "submit"
}) {
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      className={`inline-flex items-center justify-center gap-2 rounded px-4 py-2.5 text-xs font-medium transition disabled:opacity-40 ${
        secondary
          ? "border border-border bg-white hover:bg-muted"
          : "border border-primary bg-primary text-white hover:brightness-90"
      } ${className}`}
    >
      {children}
    </button>
  )
}
function IconButton({
  children,
  onClick,
  label,
}: {
  children: ReactNode
  onClick?: () => void
  label: string
}) {
  return (
    <button
      title={label}
      aria-label={label}
      onClick={onClick}
      className="flex size-8 items-center justify-center rounded text-[#74776d] transition hover:bg-muted hover:text-foreground"
    >
      {children}
    </button>
  )
}
function Badge({ status }: { status: string }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded px-2 py-1 text-[10px] font-medium ${
        status === "Published" || status === "Ready"
          ? "bg-[#eef1e6] text-[#66774a]"
          : status === "Draft" || status === "New"
            ? "bg-[#f5efe2] text-[#a3874e]"
            : "bg-muted text-muted-foreground"
      }`}
    >
      <span className="size-1 rounded-full bg-current" />
      {status}
    </span>
  )
}
function Field({ label, children }: { label: string; children?: ReactNode }) {
  return (
    <label className="block space-y-2 text-xs font-medium text-[#65685f]">
      {label}
      {children || <input className={inputClass} />}
    </label>
  )
}
function Empty({
  text = "No projects found",
  action,
}: {
  text?: string
  action?: ReactNode
}) {
  return (
    <div className="flex min-h-64 flex-col items-center justify-center gap-4 border border-dashed border-border text-center">
      <FolderOpen size={28} className="text-muted-foreground" />
      <h3 className="text-base">{text}</h3>
      <p className="text-sm text-muted-foreground">
        Try a different search or add something new.
      </p>
      {action}
    </div>
  )
}

function Workspace() {
  const navigate = useNavigate()
  const location = useLocation()
  const section = location.pathname.split("/")[1] || "dashboard"
  const [projects, setProjects] = useState<Project[]>(() => {
    try {
      return (
        JSON.parse(localStorage.getItem("architecture-projects") || "null") ||
        initialProjects
      )
    } catch {
      return initialProjects
    }
  })
  const [mobile, setMobile] = useState(false)
  const [toast, setToast] = useState("")
  const [confirm, setConfirm] = useState<{
    text: string
    action: () => void
  } | null>(null)
  const [editing, setEditing] = useState<Project | null>(null)
  const [dirty, setDirty] = useState(false)
  const [tab, setTab] = useState("Basic information")
  const [saving, setSaving] = useState(false)
  const [preview, setPreview] = useState<Project | "website" | null>(null)
  const [accent, setAccent] = useState(
    () => localStorage.getItem("architecture-accent") || "#69774c",
  )
  const [messages, setMessages] = useState([
    {
      id: 1,
      name: "Sofia Martinez",
      email: "sofia.martinez@gmail.com",
      subject: "A new home in Barcelona",
      text: "Hello Alex,\n\nWe came across your Courtyard House project and really loved your approach to light and materials. We are planning to build a family home in Barcelona and would love to explore working together.\n\nWould you be available for an initial conversation next week?\n\nBest wishes,\nSofia",
      status: "New",
      date: "Today, 10:24 AM",
    },
    {
      id: 2,
      name: "James Wilson",
      email: "james@formastudio.co",
      subject: "Potential studio collaboration",
      text: "Hi Alex, we would love to discuss an upcoming cultural project in Lisbon. Your portfolio feels like a wonderful fit. Looking forward to hearing from you.",
      status: "New",
      date: "Yesterday",
    },
    {
      id: 3,
      name: "Clara Torres",
      email: "clara.torres@gmail.com",
      subject: "Residential project enquiry",
      text: "Thank you for your time last week. I have attached the site details for our upcoming project. Let me know what you think.",
      status: "Read",
      date: "May 21, 2025",
    },
  ])
  const notify = (message: string) => setToast(message)
  useEffect(() => {
    localStorage.setItem("architecture-projects", JSON.stringify(projects))
  }, [projects])
  useEffect(() => {
    document.documentElement.style.setProperty("--primary", accent)
    document.documentElement.style.setProperty("--accent", accent)
    localStorage.setItem("architecture-accent", accent)
  }, [accent])
  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(""), 4500)
      return () => clearTimeout(timer)
    }
  }, [toast])
  useEffect(() => {
    const listener = (event: BeforeUnloadEvent) => {
      if (dirty) event.preventDefault()
    }
    window.addEventListener("beforeunload", listener)
    return () => window.removeEventListener("beforeunload", listener)
  }, [dirty])
  const closeEditor = () => {
    if (dirty)
      setConfirm({
        text: "You have unsaved changes. Discard them?",
        action: () => {
          setEditing(null)
          setDirty(false)
        },
      })
    else setEditing(null)
  }
  useEffect(() => {
    const listener = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        if (confirm) setConfirm(null)
        else if (preview) setPreview(null)
        else if (editing) closeEditor()
        else setMobile(false)
      }
    }
    window.addEventListener("keydown", listener)
    return () => window.removeEventListener("keydown", listener)
  })
  const go = (path: string) => {
    navigate(`/${path}`)
    setMobile(false)
  }
  const newProject = () => {
    setEditing({
      id: Date.now(),
      name: "",
      category: "Residential",
      location: "",
      year: "2025",
      status: "Draft",
      image: "",
    })
    setTab("Basic information")
    setDirty(false)
  }
  const editProject = (project: Project) => {
    setEditing({ ...project })
    setTab("Basic information")
    setDirty(false)
  }
  const saveProject = (status?: Status) => {
    if (!editing?.name.trim()) {
      notify("Please enter a project name.")
      return
    }
    setSaving(true)
    const updated = { ...editing, status: status || editing.status }
    setTimeout(() => {
      setProjects((previous) =>
        previous.some((item) => item.id === updated.id)
          ? previous.map((item) => (item.id === updated.id ? updated : item))
          : [updated, ...previous],
      )
      setEditing(updated)
      setDirty(false)
      setSaving(false)
      notify(
        status === "Published"
          ? "Project published successfully."
          : "Project saved successfully.",
      )
    }, 500)
  }
  const projectAction = (project: Project, action: string) => {
    if (action === "Edit") editProject(project)
    if (action === "Preview") setPreview(project)
    if (action === "Duplicate") {
      setProjects((previous) => [
        {
          ...project,
          id: Date.now(),
          name: `${project.name} — Copy`,
          status: "Draft",
        },
        ...previous,
      ])
      notify("Project duplicated as a draft.")
    }
    if (action === "Archive") {
      setProjects((previous) =>
        previous.map((item) =>
          item.id === project.id ? { ...item, status: "Archived" } : item,
        ),
      )
      notify("Project archived.")
    }
    if (action === "Delete")
      setConfirm({
        text: `Delete “${project.name}”? This action cannot be undone.`,
        action: () => {
          setProjects((previous) =>
            previous.filter((item) => item.id !== project.id),
          )
          notify("Project deleted.")
        },
      })
  }
  const unread = messages.filter((message) => message.status === "New").length
  if (section === "login") return <Login onLogin={() => go("")} />
  return (
    <div className="min-h-screen bg-background">
      {mobile && (
        <button
          aria-label="Close navigation"
          className="fixed inset-0 z-40 bg-black/25 lg:hidden"
          onClick={() => setMobile(false)}
        />
      )}
      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-[224px] flex-col border-r border-border bg-[#f5f5f1] px-5 transition-transform lg:translate-x-0 ${
          mobile ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <button
          onClick={() => go("")}
          className="flex items-center gap-3 pt-9 pb-10 text-left"
        >
          <span className="flex size-9 items-center justify-center border border-[#34382d] text-[22px] font-light">
            a<span className="text-primary">.</span>
          </span>
          <span className="text-[10px] font-semibold leading-[1.6] tracking-[1.8px]">
            ARCHITECT
            <br />
            PORTFOLIO
          </span>
        </button>
        <p className="mb-3 px-3 text-[9px] font-medium tracking-[1.5px] text-muted-foreground">
          WORKSPACE
        </p>
        <nav className="space-y-1">
          {navItems.map((item) => (
            <button
              key={item.name}
              onClick={() => go(item.path)}
              className={`flex h-[42px] w-full items-center gap-3 rounded px-3 text-xs transition ${
                section === (item.path || "dashboard")
                  ? "bg-[#e9eddf] font-medium text-primary"
                  : "text-[#787a71] hover:bg-[#eceee5] hover:text-foreground"
              }`}
            >
              <item.icon size={16} strokeWidth={1.6} />
              {item.name}
              {item.name === "Messages" && unread > 0 && (
                <span className="ml-auto rounded bg-white/80 px-1.5 py-0.5 text-[9px] text-primary">
                  {unread}
                </span>
              )}
            </button>
          ))}
        </nav>
        <div className="mt-auto pb-5">
          <div className="mb-5 rounded border border-border bg-white/50 px-3 py-3.5">
            <div className="flex items-center gap-2 text-[11px]">
              <span className="size-1.5 rounded-full bg-primary" />
              Your website is live
              <ArrowUpRight
                size={13}
                className="ml-auto text-muted-foreground"
              />
            </div>
            <p className="mt-1.5 pl-3.5 text-[10px] text-muted-foreground">
              alexmorgan.architecture
            </p>
          </div>
          <button
            onClick={() => setPreview("website")}
            className="flex w-full items-center gap-3 px-3 py-3 text-xs text-[#777a70]"
          >
            <ExternalLink size={15} />
            View website
            <ArrowUpRight size={12} className="ml-auto" />
          </button>
          <button
            onClick={() => go("login")}
            className="flex w-full items-center gap-3 px-3 py-3 text-xs text-[#777a70]"
          >
            <LogOut size={15} />
            Log out
          </button>
          <div className="mt-4 flex items-center gap-3 border-t border-border pt-5">
            <div className="flex size-8 items-center justify-center rounded-full bg-[#e5e6dc] text-[10px] font-medium">
              AM
            </div>
            <div>
              <p className="text-[11px] font-medium">Alex Morgan</p>
              <p className="mt-0.5 text-[9px] text-muted-foreground">
                Architect · Administrator
              </p>
            </div>
            <IconButton label="Profile settings" onClick={() => go("profile")}>
              <ChevronDown size={13} />
            </IconButton>
          </div>
        </div>
      </aside>
      <div className="lg:ml-[224px]">
        <header className="flex h-[73px] items-center justify-between border-b border-border bg-white/60 px-5 md:px-10">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobile(true)}
              className="lg:hidden"
              aria-label="Open navigation"
            >
              <Menu size={20} />
            </button>
            <span className="text-xs text-muted-foreground">Workspace</span>
            <ChevronRight size={11} className="text-[#b5b7ae]" />
            <span className="text-xs">
              {navItems.find((item) => (item.path || "dashboard") === section)
                ?.name || "Dashboard"}
            </span>
          </div>
          <div className="flex items-center gap-4">
            <span className="hidden text-[10px] text-muted-foreground sm:block">
              Wednesday, May 28, 2025
            </span>
            <span className="hidden h-4 w-px bg-border sm:block" />
            <IconButton
              label="Help"
              onClick={() =>
                notify("Need help? Contact support@architectportfolio.com")
              }
            >
              <CircleHelp size={16} />
            </IconButton>
            <button
              aria-label="Unread messages"
              onClick={() => go("messages")}
              className="relative p-1"
            >
              <Bell size={17} strokeWidth={1.5} />
              {unread > 0 && (
                <span className="absolute top-0 right-0 size-1.5 rounded-full border border-background bg-primary" />
              )}
            </button>
          </div>
        </header>
        <main className="mx-auto max-w-[1600px] px-5 pt-9 pb-6 md:px-10 md:pt-10">
          {section === "dashboard" && (
            <Overview
              projects={projects}
              unread={unread}
              newProject={newProject}
              go={go}
              editProject={editProject}
              projectAction={projectAction}
            />
          )}
          {section === "projects" && (
            <Projects
              projects={projects}
              newProject={newProject}
              editProject={editProject}
              projectAction={projectAction}
            />
          )}
          {section === "media" && <Media notify={notify} />}
          {section === "profile" && <Profile notify={notify} />}
          {section === "services" && <Services notify={notify} />}
          {section === "messages" && (
            <Messages
              messages={messages}
              setMessages={setMessages}
              notify={notify}
              setConfirm={setConfirm}
            />
          )}
          {section === "settings" && (
            <SettingsPage
              accent={accent}
              setAccent={setAccent}
              notify={notify}
            />
          )}
          <footer className="mt-10 flex items-center justify-between border-t border-border py-5 text-[9px] text-muted-foreground">
            <span>© 2025 Architect Portfolio</span>
            <span className="flex items-center gap-1.5">
              <span className="size-1 rounded-full bg-primary" />
              All systems operational
              <span className="ml-4 hidden sm:inline">v1.0</span>
            </span>
          </footer>
        </main>
      </div>
      {editing && (
        <div className="fixed inset-0 z-50 flex flex-col bg-background lg:left-[224px]">
          <header className="flex flex-wrap items-center justify-between gap-3 border-b border-border bg-white px-5 py-4 md:px-10">
            <div className="flex items-center gap-3">
              <IconButton label="Back to projects" onClick={closeEditor}>
                <ArrowLeft size={18} />
              </IconButton>
              <div>
                <h2 className="text-sm font-medium">
                  {editing.name || "New project"}
                </h2>
                <p className="mt-1 text-[10px] text-muted-foreground">
                  {saving
                    ? "Saving..."
                    : dirty
                      ? "You have unsaved changes"
                      : "All changes saved"}
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                secondary
                disabled={saving}
                onClick={() => saveProject("Draft")}
              >
                <Save size={13} />
                Save draft
              </Button>
              <Button secondary onClick={() => setPreview(editing)}>
                <Eye size={13} />
                Preview
              </Button>
              <Button
                disabled={saving}
                onClick={() => saveProject("Published")}
              >
                <ArrowUpRight size={13} />
                Publish
              </Button>
            </div>
          </header>
          <div className="overflow-auto px-5 py-8 md:px-10">
            <div className="mx-auto max-w-4xl">
              <p className="text-[10px] tracking-[1.4px] text-muted-foreground">
                PROJECT EDITOR
              </p>
              <h1 className="mt-2 mb-7 text-3xl">
                A space for your next idea.
              </h1>
              <div className="mb-8 flex gap-6 overflow-auto border-b border-border">
                {[
                  "Basic information",
                  "Project details",
                  "Cover",
                  "Gallery",
                  "SEO",
                ].map((item) => (
                  <button
                    key={item}
                    onClick={() => setTab(item)}
                    className={`shrink-0 border-b-2 pb-3 text-xs ${
                      tab === item
                        ? "border-primary text-primary"
                        : "border-transparent text-muted-foreground"
                    }`}
                  >
                    {item}
                  </button>
                ))}
              </div>
              {tab === "Basic information" && (
                <div className="grid gap-6 sm:grid-cols-2">
                  <Field label="Project name">
                    <input
                      className={inputClass}
                      value={editing.name}
                      onChange={(event) => {
                        setEditing({ ...editing, name: event.target.value })
                        setDirty(true)
                      }}
                      placeholder="Enter a project name"
                    />
                  </Field>
                  <Field label="Slug">
                    <input
                      className={inputClass}
                      value={editing.fields?.slug ?? editing.name.toLowerCase().replace(/\s+/g, "-")}
                      onChange={(event) => { setEditing({ ...editing, fields: { ...editing.fields, slug: event.target.value } }); setDirty(true); }}
                    />
                  </Field>
                  <div className="sm:col-span-2">
                    <Field label="Short description">
                      <textarea
                        rows={3}
                        className={inputClass}
                        value={editing.description || ""}
                        onChange={(event) => {
                          setEditing({
                            ...editing,
                            description: event.target.value,
                          })
                          setDirty(true)
                        }}
                        placeholder="A brief introduction to the project"
                      />
                    </Field>
                  </div>
                  <div className="sm:col-span-2">
                    <Field label="Long description">
                      <textarea
                        rows={6}
                        className={inputClass}
                        value={editing.fields?.longDescription || ""}
                        onChange={(event) => { setEditing({ ...editing, fields: { ...editing.fields, longDescription: event.target.value } }); setDirty(true); }}
                        placeholder="The story, concept, and design process..."
                      />
                    </Field>
                  </div>
                  {(["category", "location", "year", "status"] as const).map(
                    (key) => (
                      <Field
                        key={key}
                        label={key[0].toUpperCase() + key.slice(1)}
                      >
                        {key === "category" || key === "status" ? (
                          <select
                            className={inputClass}
                            value={editing[key]}
                            onChange={(event) => {
                              setEditing({
                                ...editing,
                                [key]: event.target.value,
                              })
                              setDirty(true)
                            }}
                          >
                            {(key === "status"
                              ? ["Draft", "Published", "Archived"]
                              : [
                                  "Residential",
                                  "Cultural",
                                  "Commercial",
                                  "Interior",
                                ]
                            ).map((option) => (
                              <option key={option}>{option}</option>
                            ))}
                          </select>
                        ) : (
                          <input
                            className={inputClass}
                            value={editing[key]}
                            onChange={(event) => {
                              setEditing({
                                ...editing,
                                [key]: event.target.value,
                              })
                              setDirty(true)
                            }}
                          />
                        )}
                      </Field>
                    ),
                  )}
                </div>
              )}
              {tab === "Project details" && (
                <div className="grid gap-6 sm:grid-cols-2">
                  {[
                    "Area (m²)",
                    "Program",
                    "Client",
                    "Role",
                    "Project status",
                  ].map((label) => (
                    <Field key={label} label={label}>
                      <input
                        className={inputClass}
                        value={editing.fields?.[label] || ""}
                        onChange={(event) => { setEditing({ ...editing, fields: { ...editing.fields, [label]: event.target.value } }); setDirty(true); }}
                      />
                    </Field>
                  ))}
                </div>
              )}
              {tab === "Cover" && (
                <div className="space-y-6">
                  {editing.image && (
                    <img
                      src={editing.image}
                      alt={editing.name}
                      className="h-72 w-full rounded object-cover"
                    />
                  )}
                  <Uploader
                    onFiles={(files) => {
                      if (files[0]) {
                        setEditing({
                          ...editing,
                          image: URL.createObjectURL(files[0]),
                        })
                        setDirty(true)
                      }
                    }}
                  />
                  <Field label="Alt text">
                    <input
                      className={inputClass}
                      onChange={() => setDirty(true)}
                      placeholder="Describe the architecture in the image"
                    />
                  </Field>
                  <Field label="Cover positioning">
                    <select
                      className={inputClass}
                      onChange={() => setDirty(true)}
                    >
                      <option>Center</option>
                      <option>Top</option>
                      <option>Bottom</option>
                    </select>
                  </Field>
                </div>
              )}
              {tab === "Gallery" && <Gallery onChange={() => setDirty(true)} />}
              {tab === "SEO" && (
                <details open className="rounded border border-border p-5">
                  <summary className="text-sm font-medium">
                    Search engine optimization
                  </summary>
                  <div className="mt-6 space-y-5">
                    <Field label="Meta title">
                      <input
                        className={inputClass}
                        value={editing.fields?.metaTitle ?? editing.name}
                        onChange={(event) => { setEditing({ ...editing, fields: { ...editing.fields, metaTitle: event.target.value } }); setDirty(true); }}
                      />
                    </Field>
                    <Field label="Meta description">
                      <textarea
                        className={inputClass}
                        rows={4}
                        value={editing.fields?.metaDescription || ""}
                        onChange={(event) => { setEditing({ ...editing, fields: { ...editing.fields, metaDescription: event.target.value } }); setDirty(true); }}
                      />
                    </Field>
                    <Field label="OG image">
                      <input
                        type="file"
                        accept="image/*"
                        className={inputClass}
                        onChange={() => setDirty(true)}
                      />
                    </Field>
                  </div>
                </details>
              )}
            </div>
          </div>
        </div>
      )}
      {preview && (
        <div className="fixed inset-0 z-[70] overflow-y-auto bg-[#f3f2ed]">
          <div className="flex items-center justify-between border-b border-border px-8 py-5">
            <span className="text-xs tracking-[2px]">
              ALEX MORGAN — ARCHITECT
            </span>
            <Button secondary onClick={() => setPreview(null)}>
              <X size={14} />
              Close preview
            </Button>
          </div>
          <div className="mx-auto max-w-6xl px-6 py-16">
            <p className="mb-5 text-xs tracking-[2px] text-muted-foreground">
              {preview === "website"
                ? "SELECTED WORKS · 2023—2025"
                : `${preview.category} / ${preview.year}`}
            </p>
            <h1 className="mb-8 text-5xl font-light md:text-7xl">
              {preview === "website"
                ? "Spaces to live. Places to belong."
                : preview.name}
            </h1>
            {preview !== "website" ? (
              <>
                <img
                  src={preview.image || initialProjects[0].image}
                  className="max-h-[65vh] w-full object-cover"
                  alt={preview.name}
                />
                <p className="mt-8 max-w-xl text-lg text-muted-foreground">
                  {preview.description ||
                    "An exploration of light, material, and the relationship between architecture and its surroundings."}
                </p>
              </>
            ) : (
              <div className="grid gap-8 md:grid-cols-2">
                {projects
                  .filter((project) => project.status === "Published")
                  .map((project) => (
                    <button
                      key={project.id}
                      className="text-left"
                      onClick={() => setPreview(project)}
                    >
                      <img
                        src={project.image}
                        alt={project.name}
                        className="aspect-[4/3] w-full object-cover"
                      />
                      <h2 className="mt-4 text-xl">{project.name}</h2>
                      <p className="mt-1 text-sm text-muted-foreground">
                        {project.location} · {project.year}
                      </p>
                    </button>
                  ))}
              </div>
            )}
          </div>
        </div>
      )}
      {confirm && (
        <div
          className="fixed inset-0 z-[80] flex items-center justify-center bg-black/25 p-5"
          onClick={() => setConfirm(null)}
        >
          <div
            role="alertdialog"
            aria-modal="true"
            aria-labelledby="confirmation"
            className="w-full max-w-md rounded-md border border-border bg-white p-8"
            onClick={(event) => event.stopPropagation()}
          >
            <Trash2 size={24} className="mb-5 text-destructive" />
            <h2 id="confirmation" className="text-lg">
              {confirm.text}
            </h2>
            <div className="mt-7 flex justify-end gap-3">
              <Button secondary onClick={() => setConfirm(null)}>
                Cancel
              </Button>
              <Button
                className="border-destructive bg-destructive"
                onClick={() => {
                  confirm.action()
                  setConfirm(null)
                }}
              >
                Confirm
              </Button>
            </div>
          </div>
        </div>
      )}
      {toast && (
        <div
          role="status"
          className="fixed right-5 bottom-5 z-[90] flex max-w-[calc(100%-40px)] items-center gap-3 rounded border border-border bg-white px-5 py-4 text-xs shadow-sm"
        >
          <CheckCircle2 size={16} className="shrink-0 text-primary" />
          {toast}
          <button
            aria-label="Dismiss notification"
            onClick={() => setToast("")}
          >
            <X size={14} />
          </button>
        </div>
      )}
    </div>
  )
}

function PageHeading({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow?: string
  title: string
  description: string
  action?: ReactNode
}) {
  return (
    <div className="mb-8 flex flex-wrap items-center justify-between gap-5">
      <div>
        {eyebrow && (
          <p className="mb-2.5 text-[9px] font-medium tracking-[1.8px] text-muted-foreground">
            {eyebrow}
          </p>
        )}
        <h1 className="font-['DM_Sans'] text-[32px] font-medium leading-tight md:text-[35px]">
          {title}
        </h1>
        <p className="mt-2.5 text-xs text-muted-foreground">{description}</p>
      </div>
      {action}
    </div>
  )
}
function Overview({
  projects,
  unread,
  newProject,
  go,
  editProject,
  projectAction,
}: {
  projects: Project[]
  unread: number
  newProject: () => void
  go: (path: string) => void
  editProject: (project: Project) => void
  projectAction: (project: Project, action: string) => void
}) {
  return (
    <>
      <PageHeading
        eyebrow="YOUR STUDIO, AT A GLANCE"
        title="Overview"
        description="Welcome back, Alex. Here's what's happening with your portfolio."
        action={
          <Button onClick={newProject}>
            <Plus size={14} />
            New project
          </Button>
        }
      />
      <div className="mb-9 grid grid-cols-2 gap-y-6 border-y border-border py-6 sm:grid-cols-5">
        {[
          {
            label: "Total projects",
            value: projects.length,
            icon: FolderOpen,
            link: "projects",
          },
          {
            label: "Published",
            value: projects.filter((item) => item.status === "Published")
              .length,
            icon: Globe,
            link: "projects",
          },
          {
            label: "Draft projects",
            value: projects.filter((item) => item.status === "Draft").length,
            icon: File,
            link: "projects",
          },
          { label: "Media files", value: 6, icon: Image, link: "media" },
          {
            label: "Unread messages",
            value: unread,
            icon: Mail,
            link: "messages",
          },
        ].map((stat, index) => (
          <button
            key={stat.label}
            onClick={() => go(stat.link)}
            className={`px-5 text-left first:pl-0 sm:border-r sm:last:border-0 ${
              index === 4 ? "col-span-2 sm:col-span-1" : ""
            } border-border`}
          >
            <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
              <stat.icon size={13} strokeWidth={1.5} />
              {stat.label}
            </div>
            <div className="mt-3 flex items-end gap-3">
              <span className="text-[32px] font-light leading-none">
                {String(stat.value).padStart(2, "0")}
              </span>
              {stat.label === "Unread messages" && unread > 0 && (
                <span className="mb-1 text-[9px] text-primary">
                  Needs attention
                </span>
              )}
            </div>
          </button>
        ))}
      </div>
      <div className="mb-5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h2 className="text-[15px] font-medium">Recent projects</h2>
          <span className="text-[10px] text-muted-foreground">
            Your latest work
          </span>
        </div>
        <button
          onClick={() => go("projects")}
          className="flex items-center gap-2 text-[10px] text-[#65695b]"
        >
          View all projects
          <ArrowRight size={13} />
        </button>
      </div>
      <div className="grid gap-5 md:grid-cols-3">
        {projects.slice(0, 3).map((project) => (
          <ProjectCard
            key={project.id}
            project={project}
            editProject={editProject}
            projectAction={projectAction}
            recent
          />
        ))}
      </div>
      <div className="mt-9 grid gap-8 xl:grid-cols-[1fr_1.2fr]">
        <div>
          <h2 className="mb-4 text-[15px] font-medium">Quick actions</h2>
          <div className="divide-y divide-border rounded border border-border bg-white/60">
            {[
              {
                title: "New project",
                text: "Bring your next project to the portfolio",
                icon: Plus,
                action: newProject,
              },
              {
                title: "Upload media",
                text: "Add images, renders, and drawings",
                icon: Upload,
                action: () => go("media"),
              },
              {
                title: "Edit profile",
                text: "Keep your story up to date",
                icon: UserRound,
                action: () => go("profile"),
              },
            ].map((item) => (
              <button
                key={item.title}
                onClick={item.action}
                className="group flex w-full items-center gap-4 px-4 py-[17px] text-left transition hover:bg-muted"
              >
                <div className="flex size-9 items-center justify-center rounded bg-[#f0f1e9] text-[#757e61]">
                  <item.icon size={16} strokeWidth={1.5} />
                </div>
                <div>
                  <h3 className="text-[11px] font-medium">{item.title}</h3>
                  <p className="mt-1 text-[10px] text-muted-foreground">
                    {item.text}
                  </p>
                </div>
                <ArrowUpRight
                  size={14}
                  className="ml-auto text-muted-foreground group-hover:text-primary"
                />
              </button>
            ))}
          </div>
        </div>
        <div>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-[15px] font-medium">Recent activity</h2>
            <span className="text-[9px] text-muted-foreground">
              LAST 7 DAYS
            </span>
          </div>
          <div className="rounded border border-border bg-white/60 px-5 py-1">
            {[
              {
                icon: Mail,
                text: "New message from Sofia Martinez",
                sub: "A new home in Barcelona",
                time: "2 hours ago",
                link: "messages",
              },
              {
                icon: CheckCircle2,
                text: "The Courtyard House published",
                sub: "Your project is now live on your website",
                time: "Yesterday",
                link: "projects",
              },
              {
                icon: Image,
                text: "6 new media files uploaded",
                sub: "Images added to your media library",
                time: "May 26",
                link: "media",
              },
              {
                icon: File,
                text: "Still House saved as draft",
                sub: "Continue where you left off",
                time: "May 25",
                link: "projects",
              },
            ].map((item) => (
              <button
                key={item.text}
                onClick={() => go(item.link)}
                className="flex w-full items-start gap-3 border-b border-border py-[17px] text-left last:border-0"
              >
                <item.icon
                  size={14}
                  strokeWidth={1.5}
                  className="mt-0.5 shrink-0 text-[#899075]"
                />
                <div>
                  <p className="text-[10px] font-medium">{item.text}</p>
                  <p className="mt-1 text-[9px] text-muted-foreground">
                    {item.sub}
                  </p>
                </div>
                <span className="ml-auto shrink-0 pt-0.5 text-[9px] text-muted-foreground">
                  {item.time}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
      <div className="mt-7 flex flex-wrap items-center gap-3 rounded border border-[#e1e5d7] bg-[#f1f3ea] px-4 py-3.5">
        <span className="flex size-7 items-center justify-center rounded-full bg-white text-primary">
          <Globe size={14} />
        </span>
        <p className="text-[10px] text-[#717b60]">
          <span className="font-medium text-[#4f5c3e]">
            A portfolio that grows with your practice.
          </span>{" "}
          Keep your latest work in the spotlight.
        </p>
        <button
          onClick={() => go("projects")}
          className="ml-auto flex items-center gap-2 text-[10px] text-primary"
        >
          Manage projects
          <ArrowRight size={12} />
        </button>
      </div>
    </>
  )
}
function ProjectCard({
  project,
  editProject,
  projectAction,
  recent = false,
}: {
  project: Project
  editProject: (project: Project) => void
  projectAction: (project: Project, action: string) => void
  recent?: boolean
}) {
  return (
    <article className="group overflow-visible rounded border border-border bg-white">
      <button
        className="block w-full overflow-hidden rounded-t"
        onClick={() => editProject(project)}
      >
        <img
          src={project.image || initialProjects[0].image}
          alt={project.name}
          className="aspect-[1.52] w-full object-cover transition duration-500 group-hover:scale-[1.025]"
        />
      </button>
      <div className="px-4 py-4">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-[9px] tracking-[1px] text-muted-foreground uppercase">
            {project.category}
          </span>
          <Badge status={project.status} />
        </div>
        <button
          className="text-left text-[13px] font-medium hover:text-primary"
          onClick={() => editProject(project)}
        >
          {project.name}
        </button>
        <p className="mt-1.5 text-[10px] text-muted-foreground">
          {project.location}
          <span className="mx-2 text-[#c2c5ba]">/</span>
          {project.year}
        </p>
        <div className="mt-4 flex items-center justify-between border-t border-border pt-2.5">
          <p className="text-[9px] text-muted-foreground">
            {recent ? "Edited " : "Last modified "}
            {project.id === 1
              ? "2 hours ago"
              : project.id === 2
                ? "yesterday"
                : "May 25, 2025"}
          </p>
          <details className="relative">
            <summary
              aria-label={`Actions for ${project.name}`}
              className="list-none rounded px-1 text-muted-foreground hover:bg-muted"
            >
              <MoreHorizontal size={17} />
            </summary>
            <div className="absolute right-0 bottom-7 z-20 w-36 rounded border border-border bg-white p-1 shadow-sm">
              {["Edit", "Preview", "Duplicate", "Archive", "Delete"].map(
                (action) => (
                  <button
                    key={action}
                    onClick={(event) => {
                      event.currentTarget
                        .closest("details")
                        ?.removeAttribute("open")
                      projectAction(project, action)
                    }}
                    className={`block w-full rounded px-3 py-2 text-left text-xs hover:bg-muted ${
                      action === "Delete" ? "text-destructive" : ""
                    }`}
                  >
                    {action}
                  </button>
                ),
              )}
            </div>
          </details>
        </div>
      </div>
    </article>
  )
}
function Projects({
  projects,
  newProject,
  editProject,
  projectAction,
}: {
  projects: Project[]
  newProject: () => void
  editProject: (project: Project) => void
  projectAction: (project: Project, action: string) => void
}) {
  const [filter, setFilter] = useState("All")
  const [search, setSearch] = useState("")
  const [mode, setMode] = useState("grid")
  const [category, setCategory] = useState("All categories")
  const [year, setYear] = useState("All years")
  const filtered = projects.filter(
    (project) =>
      (filter === "All" || project.status === filter) &&
      (category === "All categories" || project.category === category) &&
      (year === "All years" || project.year === year) &&
      `${project.name} ${project.location}`
        .toLowerCase()
        .includes(search.toLowerCase()),
  )
  return (
    <>
      <PageHeading
        eyebrow="A COLLECTION OF YOUR WORK"
        title="Projects"
        description="Curate, organize, and share the spaces you create."
        action={
          <Button onClick={newProject}>
            <Plus size={14} />
            New project
          </Button>
        }
      />
      <div className="mb-6 flex flex-wrap items-center gap-5 border-b border-border">
        {["All", "Published", "Draft", "Archived"].map((item) => (
          <button
            key={item}
            onClick={() => setFilter(item)}
            className={`flex items-center gap-2 border-b-2 pb-4 text-xs ${
              filter === item
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground"
            }`}
          >
            {item}
            <span className="text-[9px]">
              {
                projects.filter(
                  (project) => item === "All" || project.status === item,
                ).length
              }
            </span>
          </button>
        ))}
      </div>
      <div className="mb-6 flex flex-wrap items-center gap-3">
        <SearchBox
          value={search}
          setValue={setSearch}
          placeholder="Search projects..."
        />
        <select
          aria-label="Filter category"
          className={`${inputClass} w-auto text-xs`}
          value={category}
          onChange={(event) => setCategory(event.target.value)}
        >
          {[
            "All categories",
            "Residential",
            "Cultural",
            "Commercial",
            "Interior",
          ].map((item) => (
            <option key={item}>{item}</option>
          ))}
        </select>
        <select
          aria-label="Filter year"
          className={`${inputClass} w-auto text-xs`}
          value={year}
          onChange={(event) => setYear(event.target.value)}
        >
          {["All years", "2025", "2024", "2023"].map((item) => (
            <option key={item}>{item}</option>
          ))}
        </select>
        <div className="ml-auto flex rounded border border-border bg-white p-1">
          <button
            aria-label="Grid view"
            onClick={() => setMode("grid")}
            className={`rounded p-1.5 ${
              mode === "grid"
                ? "bg-muted text-primary"
                : "text-muted-foreground"
            }`}
          >
            <LayoutGrid size={16} />
          </button>
          <button
            aria-label="List view"
            onClick={() => setMode("list")}
            className={`rounded p-1.5 ${
              mode === "list"
                ? "bg-muted text-primary"
                : "text-muted-foreground"
            }`}
          >
            <List size={16} />
          </button>
        </div>
      </div>
      {filtered.length === 0 ? (
        <Empty action={<Button onClick={newProject}>New project</Button>} />
      ) : mode === "grid" ? (
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((project) => (
            <ProjectCard
              key={project.id}
              project={project}
              editProject={editProject}
              projectAction={projectAction}
            />
          ))}
        </div>
      ) : (
        <div className="divide-y divide-border border-y border-border">
          {filtered.map((project) => (
            <div
              key={project.id}
              className="flex flex-wrap items-center gap-5 py-4"
            >
              <img
                src={project.image}
                alt={project.name}
                className="h-16 w-24 rounded object-cover"
              />
              <button
                onClick={() => editProject(project)}
                className="min-w-40 text-left"
              >
                <h3 className="text-sm font-medium">{project.name}</h3>
                <p className="mt-1 text-xs text-muted-foreground">
                  {project.category} · {project.location}
                </p>
              </button>
              <span className="ml-auto text-xs text-muted-foreground">
                {project.year}
              </span>
              <Badge status={project.status} />
              <IconButton
                label="Edit project"
                onClick={() => editProject(project)}
              >
                <ArrowUpRight size={16} />
              </IconButton>
            </div>
          ))}
        </div>
      )}
      <p className="mt-6 text-[10px] text-muted-foreground">
        Showing {filtered.length} of {projects.length} projects
      </p>
    </>
  )
}
function SearchBox({
  value,
  setValue,
  placeholder,
}: {
  value: string
  setValue: (value: string) => void
  placeholder: string
}) {
  return (
    <div className="relative min-w-48 flex-1">
      <Search
        size={14}
        className="absolute top-3.5 left-3 text-muted-foreground"
      />
      <input
        aria-label={placeholder}
        placeholder={placeholder}
        className={`${inputClass} pl-9 text-xs`}
        value={value}
        onChange={(event) => setValue(event.target.value)}
      />
    </div>
  )
}
function Uploader({ onFiles }: { onFiles: (files: File[]) => void }) {
  const ref = useRef<HTMLInputElement>(null)
  const [dragging, setDragging] = useState(false)
  return (
    <div
      onDragOver={(event) => {
        event.preventDefault()
        setDragging(true)
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={(event) => {
        event.preventDefault()
        setDragging(false)
        onFiles(Array.from(event.dataTransfer.files))
      }}
      className={`flex min-h-40 flex-col items-center justify-center gap-3 rounded border border-dashed px-5 py-7 ${
        dragging
          ? "border-primary bg-secondary"
          : "border-[#cfd3c4] bg-white/50"
      }`}
    >
      <Upload size={22} strokeWidth={1.3} className="text-primary" />
      <p className="text-xs">
        <button
          onClick={() => ref.current?.click()}
          className="font-medium text-primary underline underline-offset-4"
        >
          Click to upload
        </button>
        <span className="text-muted-foreground"> or drag and drop</span>
      </p>
      <p className="text-[10px] text-muted-foreground">
        Images, renders, PDFs, videos, and 3D models
      </p>
      <input
        ref={ref}
        type="file"
        multiple
        className="hidden"
        onChange={(event) => {
          onFiles(Array.from(event.target.files || []))
          event.target.value = ""
        }}
      />
    </div>
  )
}
type Asset = {
  id: number
  name: string
  type: string
  size: string
  image: string
  mime: string
  state: string
}
function Media({ notify }: { notify: (message: string) => void }) {
  const [assets, setAssets] = useState<Asset[]>(
    initialProjects.map((project, index) => ({
      id: project.id,
      name: `${project.name.toLowerCase().replace(/\s+/g, "-")}-01.jpg`,
      type: index === 2 ? "Render" : "Image",
      size: "2.4 MB",
      image: project.image,
      mime: "image/jpeg",
      state: "Ready",
    })),
  )
  const [search, setSearch] = useState("")
  const [type, setType] = useState("All files")
  const [selected, setSelected] = useState<number[]>([])
  const [asset, setAsset] = useState<Asset | null>(null)
  const [upload, setUpload] = useState(false)
  const [sort, setSort] = useState("Newest first")
  const uploadFiles = (files: File[]) => {
    if (!files.length) return;
    const added = files.map((file, index) => ({
      id: Date.now() + index,
      name: file.name,
      type: file.type.startsWith("image")
        ? "Image"
        : file.type.includes("pdf")
          ? "PDF"
          : file.type.startsWith("video")
            ? "Video"
            : "Model",
      size: `${(file.size / 1024 / 1024).toFixed(1)} MB`,
      image: file.type.startsWith("image") ? URL.createObjectURL(file) : "",
      mime: file.type || "application/octet-stream",
      state: file.size > 100 * 1024 * 1024 ? "Failed — file exceeds 100 MB" : "Uploading 72%",
    }))
    setAssets((previous) => [...added, ...previous])
    setTimeout(() => {
      setAssets((previous) => previous.map((item) =>
        added.some((next) => next.id === item.id) && !item.state.startsWith("Failed")
          ? { ...item, state: "Processing" } : item));
    }, 650);
    setTimeout(() => {
      setAssets((previous) =>
        previous.map((item) =>
          added.some((next) => next.id === item.id) && !item.state.startsWith("Failed")
            ? { ...item, state: "Ready" }
            : item,
        ),
      )
      notify(
        `${files.length} file${
          files.length === 1 ? "" : "s"
        } added to this session.`,
      )
    }, 1200)
  }
  const filtered = assets
    .filter(
      (item) =>
        item.name.includes(search.toLowerCase()) &&
        (type === "All files" || item.type === type),
    )
    .sort((first, second) =>
      sort === "Name A–Z"
        ? first.name.localeCompare(second.name)
        : second.id - first.id,
    )
  return (
    <>
      <PageHeading
        eyebrow="YOUR MATERIAL PALETTE"
        title="Media library"
        description="All your images, renders, and files. One considered collection."
        action={
          <Button onClick={() => setUpload(!upload)}>
            <Upload size={14} />
            Upload media
          </Button>
        }
      />
      {upload && (
        <div className="mb-6">
          <Uploader onFiles={uploadFiles} />
        </div>
      )}
      <div className="mb-6 flex flex-wrap gap-3">
        <SearchBox
          value={search}
          setValue={setSearch}
          placeholder="Search files..."
        />
        <select
          aria-label="File type"
          className={`${inputClass} w-auto text-xs`}
          value={type}
          onChange={(event) => setType(event.target.value)}
        >
          {["All files", "Image", "Render", "PDF", "Video", "Model"].map(
            (item) => (
              <option key={item}>{item}</option>
            ),
          )}
        </select>
        <select
          aria-label="Sort files"
          className={`${inputClass} w-auto text-xs`}
          value={sort}
          onChange={(event) => setSort(event.target.value)}
        >
          <option>Newest first</option>
          <option>Name A–Z</option>
        </select>
      </div>
      {selected.length > 0 && (
        <div className="mb-4 flex items-center gap-4 text-xs">
          <span>{selected.length} files selected</span>
          <button className="text-primary" onClick={() => setSelected([])}>
            Clear selection
          </button>
        </div>
      )}
      <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
        {filtered.map((item) => (
          <article
            key={item.id}
            className={`overflow-hidden rounded border bg-white ${
              selected.includes(item.id) ? "border-primary" : "border-border"
            }`}
          >
            <div className="relative">
              <button className="block w-full" onClick={() => setAsset(item)}>
                {item.image ? (
                  <img
                    src={item.image}
                    alt={item.name}
                    className="aspect-[1.2] w-full object-cover"
                  />
                ) : (
                  <div className="flex aspect-[1.2] items-center justify-center bg-muted">
                    <File size={35} className="text-muted-foreground" />
                  </div>
                )}
              </button>
              <input
                aria-label={`Select ${item.name}`}
                type="checkbox"
                checked={selected.includes(item.id)}
                onChange={(event) =>
                  setSelected((previous) =>
                    event.target.checked
                      ? [...previous, item.id]
                      : previous.filter((id) => id !== item.id),
                  )
                }
                className="absolute top-3 left-3 size-3.5 accent-primary"
              />
            </div>
            <div className="p-3">
              <button
                onClick={() => setAsset(item)}
                className="w-full truncate text-left text-[10px] font-medium"
              >
                {item.name}
              </button>
              <p className="mt-2 flex justify-between text-[9px] text-muted-foreground">
                <span>
                  {item.type} · {item.size}
                </span>
                <span>May 26</span>
              </p>
              {item.state !== "Ready" && (
                <p className="mt-2 text-[10px] text-primary">{item.state}</p>
              )}
            </div>
          </article>
        ))}
      </div>
      {!filtered.length && <Empty text="No media files found" />}
      <p className="mt-5 text-[10px] text-muted-foreground">
        {filtered.length} files · Files are available in this prototype session
      </p>
      {asset && (
        <div
          className="fixed inset-0 z-[60] bg-black/20"
          onClick={() => setAsset(null)}
        >
          <aside
            role="dialog"
            aria-modal="true"
            aria-label="File details"
            className="absolute inset-y-0 right-0 w-full max-w-md overflow-auto border-l border-border bg-white p-6"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-lg">File details</h2>
              <IconButton
                label="Close file details"
                onClick={() => setAsset(null)}
              >
                <X size={18} />
              </IconButton>
            </div>
            {asset.image ? (
              <img
                src={asset.image}
                alt={asset.name}
                className="mb-6 aspect-[4/3] w-full object-cover"
              />
            ) : (
              <div className="mb-6 flex h-48 items-center justify-center bg-muted">
                <Box size={40} />
              </div>
            )}
            <div className="space-y-5">
              <Field label="Filename">
                <input className={inputClass} defaultValue={asset.name} />
              </Field>
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{asset.mime}</span>
                <span>{asset.size}</span>
              </div>
              <p className="text-xs text-muted-foreground">
                Dimensions:{" "}
                {asset.image ? "Preview available" : "Not applicable"}
              </p>
              <Field label="Alt text">
                <textarea
                  rows={3}
                  className={inputClass}
                  placeholder="Describe this file"
                />
              </Field>
              <Field label="Associated projects">
                <select className={inputClass}>
                  {initialProjects.map((project) => (
                    <option key={project.id}>{project.name}</option>
                  ))}
                </select>
              </Field>
              <p className="text-xs text-muted-foreground">
                Uploaded May 26, 2025
              </p>
              <Button
                onClick={() => {
                  notify("File details saved.")
                  setAsset(null)
                }}
              >
                Save details
              </Button>
            </div>
          </aside>
        </div>
      )}
    </>
  )
}
function Gallery({ onChange }: { onChange: () => void }) {
  const [files, setFiles] = useState<{ name: string; url: string }[]>([])
  const [drag, setDrag] = useState<number | null>(null)
  return (
    <>
      <Uploader
        onFiles={(added) => {
          setFiles((previous) => [
            ...previous,
            ...added.map((file) => ({
              name: file.name,
              url: URL.createObjectURL(file),
            })),
          ])
          onChange()
        }}
      />
      <div className="mt-6 grid gap-5 sm:grid-cols-2">
        {files.map((file, index) => (
          <div
            key={file.url}
            draggable
            onDragStart={() => setDrag(index)}
            onDragOver={(event) => event.preventDefault()}
            onDrop={() => {
              if (drag !== null) {
                const reordered = [...files]
                const [moved] = reordered.splice(drag, 1)
                reordered.splice(index, 0, moved)
                setFiles(reordered)
                onChange()
              }
            }}
            className="space-y-3 rounded border border-border bg-white p-3"
          >
            <img
              src={file.url}
              alt={file.name}
              className="h-40 w-full object-cover"
            />
            <div className="flex items-center justify-between text-xs">
              <GripVertical size={14} />
              {file.name}
              <IconButton
                label="Remove gallery item"
                onClick={() => {
                  setFiles((previous) =>
                    previous.filter((item) => item.url !== file.url),
                  )
                  onChange()
                }}
              >
                <X size={14} />
              </IconButton>
            </div>
            <input
              aria-label="Caption"
              className={inputClass}
              placeholder="Caption"
              onChange={onChange}
            />
            <input
              aria-label="Alt text"
              className={inputClass}
              placeholder="Alt text"
              onChange={onChange}
            />
          </div>
        ))}
      </div>
      <p className="mt-5 text-xs text-muted-foreground">
        Drag items to reorder your gallery.
      </p>
    </>
  )
}

function Profile({ notify }: { notify: (message: string) => void }) {
  const [name, setName] = useState("Alex Morgan")
  const [bio, setBio] = useState(
    "I am an architect based in Barcelona, working at the intersection of space, material, and everyday life. My practice is rooted in a belief that thoughtful architecture can make the ordinary extraordinary.",
  )
  const [portrait, setPortrait] = useState("")
  return (
    <>
      <PageHeading
        eyebrow="THE PERSON BEHIND THE PRACTICE"
        title="Profile"
        description="Tell your story. Make a meaningful first impression."
        action={
          <Button
            onClick={() => {
              localStorage.setItem(
                "architecture-profile",
                JSON.stringify({ name, bio }),
              )
              notify("Profile saved successfully.")
            }}
          >
            <Check size={14} />
            Save changes
          </Button>
        }
      />
      <div className="grid gap-10 xl:grid-cols-[1.3fr_1fr]">
        <div className="space-y-7">
          <section className="border-b border-border pb-7">
            <h2 className="mb-5 text-sm font-medium">Profile photo</h2>
            <div className="flex items-center gap-5">
              <div className="flex size-20 items-center justify-center overflow-hidden rounded-full bg-[#e7e9df] text-2xl text-primary">
                {portrait ? (
                  <img
                    src={portrait}
                    alt="Profile portrait"
                    className="size-full object-cover"
                  />
                ) : (
                  "AM"
                )}
              </div>
              <label className="cursor-pointer rounded border border-border bg-white px-4 py-2 text-xs">
                Replace photo
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(event) => {
                    if (event.target.files?.[0])
                      setPortrait(URL.createObjectURL(event.target.files[0]))
                  }}
                />
              </label>
            </div>
          </section>
          <Field label="Full name">
            <input
              className={inputClass}
              value={name}
              onChange={(event) => setName(event.target.value)}
            />
          </Field>
          <Field label="Short introduction">
            <input
              className={inputClass}
              defaultValue="Architecture grounded in life."
            />
          </Field>
          <Field label="Biography">
            <textarea
              className={inputClass}
              rows={6}
              value={bio}
              onChange={(event) => setBio(event.target.value)}
            />
          </Field>
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Location">
              <input className={inputClass} defaultValue="Barcelona, Spain" />
            </Field>
            <Field label="Experience">
              <input className={inputClass} defaultValue="12 years" />
            </Field>
          </div>
          <h2 className="border-t border-border pt-6 text-sm font-medium">
            Social links
          </h2>
          <div className="grid gap-5 sm:grid-cols-2">
            {["Instagram", "LinkedIn", "Behance", "Email"].map((label) => (
              <Field key={label} label={label}>
                <input
                  className={inputClass}
                  placeholder={
                    label === "Email" ? "alex@studio.com" : "https://"
                  }
                />
              </Field>
            ))}
          </div>
          <Field label="CV / résumé">
            <input
              type="file"
              accept="application/pdf"
              className={inputClass}
            />
          </Field>
        </div>
        <aside>
          <p className="mb-4 text-[10px] tracking-[1.5px] text-muted-foreground">
            PUBLIC PROFILE PREVIEW
          </p>
          <div className="border border-border bg-[#f1f0ea] px-7 py-10">
            <p className="text-[9px] tracking-[2px] text-muted-foreground">
              ABOUT THE PRACTICE
            </p>
            <h2 className="mt-6 text-4xl font-light">{name}</h2>
            <p className="mt-3 text-xs text-muted-foreground">
              Architect · Barcelona, Spain
            </p>
            <div className="my-8 h-px bg-border" />
            <p className="text-xl font-light leading-relaxed">
              Architecture grounded in life.
            </p>
            <p className="mt-5 text-sm leading-7 text-muted-foreground">
              {bio}
            </p>
            <span className="mt-8 inline-flex items-center gap-3 border-b border-foreground pb-2 text-xs">
              Get in touch
              <ArrowUpRight size={14} />
            </span>
          </div>
        </aside>
      </div>
    </>
  )
}
function Services({ notify }: { notify: (message: string) => void }) {
  const [services, setServices] = useState([
    {
      id: 1,
      title: "Architectural design",
      description:
        "Thoughtful spaces, from the first sketch to the final detail.",
      visible: true,
    },
    {
      id: 2,
      title: "Interior architecture",
      description: "Materials, light, and proportion in quiet harmony.",
      visible: true,
    },
    {
      id: 3,
      title: "Design consultancy",
      description: "A fresh perspective for your next project.",
      visible: false,
    },
  ])
  const [drag, setDrag] = useState<number | null>(null)
  const [edit, setEdit] = useState<number | null>(null)
  return (
    <>
      <PageHeading
        eyebrow="WHAT YOUR PRACTICE OFFERS"
        title="Services"
        description="Shape your offering. Drag to arrange the order on your website."
        action={
          <Button
            onClick={() => {
              const id = Date.now()
              setServices((previous) => [
                ...previous,
                { id, title: "New service", description: "", visible: false },
              ])
              setEdit(id)
            }}
          >
            <Plus size={14} />
            Add service
          </Button>
        }
      />
      <div className="space-y-4">
        {services.map((service, index) => (
          <div
            key={service.id}
            draggable={edit !== service.id}
            onDragStart={() => setDrag(index)}
            onDragOver={(event) => event.preventDefault()}
            onDrop={() => {
              if (drag !== null) {
                const updated = [...services]
                const [moved] = updated.splice(drag, 1)
                updated.splice(index, 0, moved)
                setServices(updated)
                notify("Service order updated.")
              }
            }}
            className="rounded border border-border bg-white p-5"
          >
            <div className="flex items-center gap-4">
              <GripVertical size={18} className="text-muted-foreground" />
              <span className="text-xs text-muted-foreground">
                0{index + 1}
              </span>
              <div className="flex-1">
                <h3 className="text-sm font-medium">{service.title}</h3>
                <p className="mt-2 text-xs text-muted-foreground">
                  {service.description}
                </p>
              </div>
              <button
                onClick={() =>
                  setServices((previous) =>
                    previous.map((item) =>
                      item.id === service.id
                        ? { ...item, visible: !item.visible }
                        : item,
                    ),
                  )
                }
              >
                <Badge status={service.visible ? "Published" : "Draft"} />
              </button>
              <IconButton
                label="Edit service"
                onClick={() => setEdit(edit === service.id ? null : service.id)}
              >
                <SlidersHorizontal size={15} />
              </IconButton>
            </div>
            {edit === service.id && (
              <div className="mt-6 space-y-4 border-t border-border pt-5">
                <Field label="Title">
                  <input
                    className={inputClass}
                    value={service.title}
                    onChange={(event) =>
                      setServices((previous) =>
                        previous.map((item) =>
                          item.id === service.id
                            ? { ...item, title: event.target.value }
                            : item,
                        ),
                      )
                    }
                  />
                </Field>
                <Field label="Short description">
                  <textarea
                    className={inputClass}
                    value={service.description}
                    onChange={(event) =>
                      setServices((previous) =>
                        previous.map((item) =>
                          item.id === service.id
                            ? { ...item, description: event.target.value }
                            : item,
                        ),
                      )
                    }
                  />
                </Field>
                <Field label="Long description">
                  <textarea rows={4} className={inputClass} />
                </Field>
                <Field label="Service image">
                  <input type="file" accept="image/*" className={inputClass} />
                </Field>
                <Button
                  onClick={() => {
                    setEdit(null)
                    notify("Service saved successfully.")
                  }}
                >
                  Save service
                </Button>
              </div>
            )}
          </div>
        ))}
      </div>
    </>
  )
}
type Message = {
  id: number
  name: string
  email: string
  subject: string
  text: string
  status: string
  date: string
}
function Messages({
  messages,
  setMessages,
  notify,
  setConfirm,
}: {
  messages: Message[]
  setMessages: (value: Message[]) => void
  notify: (message: string) => void
  setConfirm: (value: { text: string; action: () => void }) => void
}) {
  const [selected, setSelected] = useState(1)
  const [filter, setFilter] = useState("All")
  const [search, setSearch] = useState("")
  const current = messages.find((item) => item.id === selected)
  const update = (status: string) => {
    setMessages(
      messages.map((item) =>
        item.id === selected ? { ...item, status } : item,
      ),
    )
    notify(`Message marked as ${status.toLowerCase()}.`)
  }
  return (
    <>
      <PageHeading
        eyebrow="CONVERSATIONS & POSSIBILITIES"
        title="Messages"
        description="Enquiries from your portfolio, thoughtfully organized."
      />
      <div className="mb-5 flex flex-wrap gap-5">
        {["All", "New", "Read", "Archived"].map((item) => (
          <button
            key={item}
            onClick={() => setFilter(item)}
            className={`border-b-2 pb-2 text-xs ${
              filter === item
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground"
            }`}
          >
            {item}
          </button>
        ))}
      </div>
      <div className="grid min-h-[510px] overflow-hidden rounded border border-border bg-white md:grid-cols-[300px_1fr]">
        <div className="border-b border-border md:border-r">
          <div className="p-4">
            <SearchBox
              value={search}
              setValue={setSearch}
              placeholder="Search messages..."
            />
          </div>
          {messages
            .filter(
              (item) =>
                (filter === "All" || item.status === filter) &&
                `${item.name} ${item.subject}`
                  .toLowerCase()
                  .includes(search.toLowerCase()),
            )
            .map((item) => (
              <button
                key={item.id}
                onClick={() => setSelected(item.id)}
                className={`block w-full border-t border-border px-5 py-5 text-left ${
                  selected === item.id ? "bg-[#f0f2e9]" : "hover:bg-muted"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium">{item.name}</span>
                  {item.status === "New" && (
                    <span className="size-1.5 rounded-full bg-primary" />
                  )}
                </div>
                <h3 className="mt-2 text-[11px]">{item.subject}</h3>
                <p className="mt-2 truncate text-[10px] text-muted-foreground">
                  {item.text}
                </p>
                <p className="mt-3 text-[9px] text-muted-foreground">
                  {item.date}
                </p>
              </button>
            ))}
        </div>
        {current ? (
          <div className="p-6 md:p-8">
            <div className="flex items-center justify-between">
              <Badge status={current.status} />
              <div className="flex gap-1">
                <IconButton label="Mark as read" onClick={() => update("Read")}>
                  <Check size={15} />
                </IconButton>
                <IconButton
                  label="Archive message"
                  onClick={() => update("Archived")}
                >
                  <FolderOpen size={15} />
                </IconButton>
                <IconButton
                  label="Delete message"
                  onClick={() =>
                    setConfirm({
                      text: "Delete this message? This action cannot be undone.",
                      action: () => {
                        setMessages(
                          messages.filter((item) => item.id !== selected),
                        )
                        setSelected(
                          messages.find((item) => item.id !== selected)?.id ||
                            0,
                        )
                        notify("Message deleted.")
                      },
                    })
                  }
                >
                  <Trash2 size={15} />
                </IconButton>
              </div>
            </div>
            <h2 className="mt-7 text-2xl">{current.subject}</h2>
            <p className="mt-5 text-xs font-medium">{current.name}</p>
            <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
              {current.email}
              <IconButton
                label="Copy email"
                onClick={() => {
                  navigator.clipboard.writeText(current.email).then(
                    () => notify("Email copied."),
                    () => notify("Unable to access clipboard."),
                  )
                }}
              >
                <Copy size={12} />
              </IconButton>
            </div>
            <p className="mt-2 text-[10px] text-muted-foreground">
              {current.date}
            </p>
            <p className="mt-8 border-t border-border pt-7 text-sm leading-7 whitespace-pre-line text-[#6d7066]">
              {current.text}
            </p>
            <a
              className="mt-8 inline-flex items-center gap-2 rounded bg-primary px-4 py-2.5 text-xs text-white"
              href={`mailto:${current.email}?subject=Re: ${encodeURIComponent(current.subject)}`}
            >
              <ArrowUpRight size={14} />
              Reply by email
            </a>
          </div>
        ) : (
          <Empty text="No message selected" />
        )}
      </div>
    </>
  )
}
function SettingsPage({
  accent,
  setAccent,
  notify,
}: {
  accent: string
  setAccent: (value: string) => void
  notify: (message: string) => void
}) {
  const [tab, setTab] = useState("General")
  const [maintenance, setMaintenance] = useState(false)
  return (
    <>
      <PageHeading
        eyebrow="MAKE IT YOURS"
        title="Settings"
        description="The essential details behind your portfolio."
        action={
          <Button onClick={() => notify("Settings saved successfully.")}>
            <Check size={14} />
            Save changes
          </Button>
        }
      />
      <div className="grid gap-8 md:grid-cols-[180px_1fr]">
        <div className="flex flex-wrap gap-1 md:block md:space-y-1">
          {[
            "General",
            "Branding",
            "Contact",
            "Social networks",
            "SEO",
            "Website visibility",
          ].map((item) => (
            <button
              key={item}
              onClick={() => setTab(item)}
              className={`block rounded px-3 py-3 text-left text-xs md:w-full ${
                tab === item
                  ? "bg-secondary text-primary"
                  : "text-muted-foreground hover:bg-muted"
              }`}
            >
              {item}
            </button>
          ))}
        </div>
        <div className="max-w-2xl space-y-6 rounded border border-border bg-white p-6 md:p-8">
          <h2 className="border-b border-border pb-5 text-lg">{tab}</h2>
          {tab === "General" && (
            <>
              <Field label="Site title">
                <input
                  className={inputClass}
                  defaultValue="Alex Morgan — Architecture"
                />
              </Field>
              <Field label="Site description">
                <textarea
                  className={inputClass}
                  rows={4}
                  defaultValue="Architecture grounded in life. Selected projects by Alex Morgan, Barcelona."
                />
              </Field>
              <Field label="Language">
                <select className={inputClass}>
                  <option>English</option>
                  <option>Español</option>
                  <option>Português</option>
                </select>
              </Field>
            </>
          )}
          {tab === "Branding" && (
            <>
              <Field label="Logo">
                <input type="file" accept="image/*" className={inputClass} />
              </Field>
              <Field label="Favicon">
                <input type="file" accept="image/*" className={inputClass} />
              </Field>
              <Field label="Accent color">
                <div className="flex items-center gap-4">
                  <input
                    aria-label="Accent color"
                    type="color"
                    value={accent}
                    onChange={(event) => setAccent(event.target.value)}
                    className="size-10 cursor-pointer rounded border border-border"
                  />
                  <span className="text-xs">{accent}</span>
                </div>
              </Field>
              <p className="text-xs leading-6 text-muted-foreground">
                Used sparingly for primary actions, active navigation, and
                feedback.
              </p>
            </>
          )}
          {tab === "Contact" &&
            ["Email", "Phone", "Location"].map((label) => (
              <Field key={label} label={label}>
                <input
                  className={inputClass}
                  defaultValue={
                    label === "Email"
                      ? "hello@alexmorgan.architecture"
                      : label === "Location"
                        ? "Barcelona, Spain"
                        : "+34 612 345 678"
                  }
                />
              </Field>
            ))}
          {tab === "Social networks" &&
            ["Instagram", "LinkedIn", "Behance"].map((label) => (
              <Field key={label} label={label}>
                <input className={inputClass} placeholder="https://" />
              </Field>
            ))}
          {tab === "SEO" && (
            <>
              <Field label="Meta title">
                <input
                  className={inputClass}
                  defaultValue="Alex Morgan — Architecture"
                />
              </Field>
              <Field label="Meta description">
                <textarea className={inputClass} rows={4} />
              </Field>
              <Field label="OG image">
                <input type="file" accept="image/*" className={inputClass} />
              </Field>
            </>
          )}
          {tab === "Website visibility" && (
            <>
              <div className="flex items-center justify-between gap-4">
                <div>
                  <h3 className="text-sm">Maintenance mode</h3>
                  <p className="mt-2 text-xs leading-5 text-muted-foreground">
                    Temporarily show a maintenance notice on your public
                    website.
                  </p>
                </div>
                <button
                  role="switch"
                  aria-checked={maintenance}
                  aria-label="Maintenance mode"
                  onClick={() => setMaintenance(!maintenance)}
                  className={`relative h-6 w-11 shrink-0 rounded-full transition ${
                    maintenance ? "bg-primary" : "bg-[#d9dcd2]"
                  }`}
                >
                  <span
                    className={`absolute top-0.5 size-5 rounded-full bg-white transition ${
                      maintenance ? "left-[22px]" : "left-0.5"
                    }`}
                  />
                </button>
              </div>
              <p className="rounded bg-muted p-4 text-xs text-muted-foreground">
                {maintenance
                  ? "Maintenance mode enabled in this preview."
                  : "Your website is visible to visitors."}
              </p>
            </>
          )}
        </div>
      </div>
    </>
  )
}
function Login({ onLogin }: { onLogin: () => void }) {
  const location = useLocation();
  const expired = new URLSearchParams(location.search).get("expired") === "1";
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="relative hidden lg:block">
        <img
          src={initialProjects[0].image}
          alt="Quiet modern architecture"
          className="absolute size-full object-cover"
        />
        <div className="absolute inset-0 bg-black/15" />
        <p className="absolute bottom-14 left-12 text-4xl font-light leading-tight text-white">
          Good architecture.
          <br />
          Thoughtfully presented.
        </p>
      </div>
      <div className="flex flex-col px-8 py-10">
        <span className="text-xs font-medium tracking-[2px]">
          ARCHITECT PORTFOLIO
        </span>
        <form
          className="m-auto w-full max-w-sm py-16"
          onSubmit={(event) => {
            event.preventDefault()
            setLoading(true)
            setTimeout(onLogin, 650)
          }}
        >
          <p className="mb-4 text-[10px] tracking-[2px] text-muted-foreground">
            YOUR PRIVATE WORKSPACE
          </p>
          <h1 className="text-4xl">Welcome back</h1>
          {expired && <div role="alert" className="mt-5 rounded border border-[#e1d6bf] bg-[#f5efe2] p-4 text-xs leading-5 text-[#8b733e]">Your session has expired. Sign in again to continue. Your saved work is safe.</div>}
          <p className="mt-3 mb-9 text-sm text-muted-foreground">
            A considered space to manage your practice.
          </p>
          <div className="space-y-5">
            <Field label="Email">
              <input
                required
                type="email"
                autoComplete="email"
                className={inputClass}
                value={email}
                onChange={(event) => setEmail(event.target.value)}
              />
            </Field>
            <Field label="Password">
              <input
                required
                minLength={6}
                type="password"
                autoComplete="current-password"
                className={inputClass}
                value={password}
                onChange={(event) => setPassword(event.target.value)}
              />
            </Field>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Signing in..." : "Sign in"}
              <ArrowRight size={14} />
            </Button>
          </div>
          <p className="mt-6 text-center text-[10px] leading-5 text-muted-foreground">
            Interactive design preview. Use any email and a password of at least
            6 characters. No credentials are stored.
          </p>
        </form>
        <p className="text-[10px] text-muted-foreground">
          © 2025 Architect Portfolio
        </p>
      </div>
    </div>
  )
}
const router = createBrowserRouter([{ path: "*", Component: Workspace }])
export default function App() {
  return <RouterProvider router={router} />
}
